
# Using R, Given summary of the dataset, cleaned the dataset, some visualizations and Given analysis for research question 2.

#load packages
library(dplyr)
library(ggplot2)
library(tidyverse)

# Read the hurricane dataset (assuming it's named "hurricane_data.csv")
df <- read.csv("Violence_Reduction_-_Victim_Demographics_-_Aggregated.csv", header=TRUE, sep=",")

#========================================================================================================

# Explore the structure of the dataset
str(df)

# Summary statistics
summary(df)

#==========================================================================================================

# data cleaning 
# Convert relevant columns to appropriate data types, handle missing values, etc.

# Convert date column to Date type
df$TIME_PERIOD_START <- as.Date(df$TIME_PERIOD_START, format = "%m-%d-%Y")
df$TIME_PERIOD_END <- as.Date(df$TIME_PERIOD_END, format = "%m/%d/%Y")

# Display the cleaned dataset
head(df)

#==========================================================================================================

#some visualizations

# Pie chart for the proportion of domestic violence incidents
# It proves that the higher prevalence of domestic violence data present in the dataset.
ggplot(df, aes(x = "", fill = DOMESTIC_I)) +
  geom_bar(width = 1, position = 'fill') +
  coord_polar(theta = "y") +
  labs(title = 'Proportion of Domestic Violence Incidents',
       fill = 'Domestic Violence') +
  scale_fill_manual(values = c("orange", "lightblue"), name = "Incident Type", labels = c("Absent", "Present")) +
  theme_minimal()




# Stacked bar plot for the distribution of domestic violence by gender 
ggplot(df, aes(x = SEX, fill = DOMESTIC_I)) +
  geom_bar(position = 'stack') +
  labs(title = 'Distribution of Domestic Violence by Gender',
       x = 'Gender', y = 'Count',
       fill = 'Domestic Violence') +
  scale_fill_manual(values = c("red", "black"), name = "Domestic Violence", labels = c("Absent", "Present")) +
  theme_minimal()


#Bar plot for the distribution of crime types
ggplot(df, aes(x = PRIMARY_TYPE, fill = PRIMARY_TYPE)) +
  geom_bar() +
  labs(title = 'Distribution of Crime Types',
       x = 'Crime Type', y = 'Count') +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))



#============================================================================================================


# Research Question 2

# Sort racial groups for better visualization
racial_groups <- unique(df$RACE)
racial_groups <- racial_groups[order(racial_groups)]

# Define a mapping from abbreviations to full forms
race_mapping <- c("BLK" = "Black", "WHI" = "White", "UNKNOWN" = "Unknown", 
                  "WWH" = "White - Non-Hispanic", "WBH" = "White - Black/Hispanic", 
                  "API" = "Asian/Pacific Islander", "I" = "Indigenous")

# Bar plot for the number of victims (NUMBER_OF_VICTIMS) across racial groups
ggplot(df, aes(x = factor(RACE, levels = racial_groups), fill = RACE)) +
  geom_bar(position = 'dodge', color = 'black') +
  labs(title = 'Victimization Rates Across Racial Groups',
       x = 'Racial Group', y = 'Number of Victims') +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  scale_x_discrete(labels = race_mapping)


















