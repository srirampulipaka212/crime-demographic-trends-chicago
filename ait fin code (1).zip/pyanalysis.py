#Using python, cleaned the dataset, given some visualizations and produced plots for Research questions 1 and 3.

#Code:
#Import package and read the file

import pandas as pd

# Load the dataset into a Pandas DataFrame
df = pd.read_csv('Violence_Reduction_-_Victim_Demographics_-_Aggregated.csv')  

###################################################################################################

# Clean the dataset

# Convert 'TIME_PERIOD_START' and 'TIME_PERIOD_END' to datetime
df['TIME_PERIOD_START'] = pd.to_datetime(df['TIME_PERIOD_START'], errors='coerce')
df['TIME_PERIOD_END'] = pd.to_datetime(df['TIME_PERIOD_END'], errors='coerce')

################################################################################################

# Visualizations using the dataset

import matplotlib.pyplot as plt

# Bar Plot of Crime Types
crime_count = df['PRIMARY_TYPE'].value_counts().head(10)
plt.barh(crime_count.index, crime_count.values, color='green')
plt.title('Crime Types and Frequency')
plt.xlabel('Frequency')
plt.ylabel('Crime Type')
plt.show()

# Age Distribution of Victims

plt.figure(figsize=(10, 6))
plt.hist(df['AGE'], bins=10, color='pink', edgecolor='black')
plt.title('Age Distribution of Victims')
plt.xlabel('Age')
plt.ylabel('Frequency')
plt.grid(axis='y')
plt.show()

################################################################################################

#RESEARCH QUE AND PLOTS

# Research Question 1: Does the age group of offenders have an impact on the likelihood of domestic violence (DOMESTIC_I)?

import matplotlib.pyplot as plt

# Group the data by age group and calculate the mean of DOMESTIC_I
age_domestic_impact = df.groupby('AGE')['DOMESTIC_I'].mean().reset_index()

# Plot the relationship between age and domestic violence
plt.figure(figsize=(10, 6))
plt.bar(age_domestic_impact['AGE'], age_domestic_impact['DOMESTIC_I'])
plt.xlabel('Age Group')
plt.ylabel('Average Domestic Violence Impact')
plt.title('Impact of Age on Domestic Violence')
plt.xticks(rotation=45)
plt.show()


# Research Question 3: Is there a correlation between the age of offenders (AGE) and the severity of crimes (PRIMARY_TYPE)?

#Specifically, we want to investigate if certain age groups tend to commit more severe crimes than others.


import numpy as np

# Group the data by age group and primary crime type, and calculate the mean of victim counts
age_crime_severity = df.groupby(['AGE', 'PRIMARY_TYPE'])['NUMBER_OF_VICTIMS'].mean().unstack()

# Sort the columns and rows for better visualization
age_crime_severity = age_crime_severity.sort_index(ascending=False)
age_crime_severity = age_crime_severity.reindex(sorted(age_crime_severity.columns, key=lambda x: age_crime_severity[x].sum(), reverse=True), axis=1)

# Create a heatmap to visualize the correlation
plt.figure(figsize=(12, 8))
plt.imshow(age_crime_severity, cmap='YlOrRd', aspect='auto', interpolation='nearest')
plt.colorbar(label='Mean Number of Victims')
plt.xlabel('Crime Type')
plt.ylabel('Age Group')
plt.title('Correlation Between Age of Offenders and Crime Severity')
plt.xticks(np.arange(len(age_crime_severity.columns)), age_crime_severity.columns, rotation=90)
plt.yticks(np.arange(len(age_crime_severity.index)), age_crime_severity.index)
plt.show()
