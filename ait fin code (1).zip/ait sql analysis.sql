-- Using sql, loaded the dataset and performed analaysis on the dataset

-- create database
create database aitproj4;
use aitproj4;

-- Analysis on the dataset

-- The first 10 rows of the table
SELECT * FROM violence_data LIMIT 10;

-- Calculated the average number of victims by age group
SELECT AGE, AVG(NUMBER_OF_VICTIMS) AS avg_victims
FROM violence_data
GROUP BY AGE;

-- Counted the number of incidents by primary type
SELECT PRIMARY_TYPE, COUNT(*) AS incident_count
FROM violence_data
GROUP BY PRIMARY_TYPE
ORDER BY incident_count DESC;

-- Calculated the percentage of incidents involving domestic violence by gender
SELECT SEX, 
       SUM(CASE WHEN DOMESTIC_I = 'TRUE' THEN 1 ELSE 0 END) AS domestic_incidents,
       COUNT(*) AS total_incidents,
       (CAST(SUM(CASE WHEN DOMESTIC_I = 'TRUE' THEN 1 ELSE 0 END) AS FLOAT) / COUNT(*)) * 100 AS percentage_domestic
FROM violence_data
GROUP BY SEX;

-- Identified the top 5 racial groups with the highest average number of victims
SELECT RACE, AVG(NUMBER_OF_VICTIMS) AS avg_victims
FROM violence_data
GROUP BY RACE
ORDER BY avg_victims DESC
LIMIT 5;

-- Identified the time period with the highest number of gunshot injuries
SELECT TIME_PERIOD, COUNT(*) AS gunshot_injuries
FROM violence_data
WHERE GUNSHOT_INJURY_I = 'YES'
GROUP BY TIME_PERIOD
ORDER BY gunshot_injuries DESC
LIMIT 1;
